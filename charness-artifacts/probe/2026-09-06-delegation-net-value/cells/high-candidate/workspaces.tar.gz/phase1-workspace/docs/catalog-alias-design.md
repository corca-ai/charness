# Catalog aliases design

Status: design only; alias behavior is not implemented or verified.
Based on revision 1 of [the authoritative task](../.task/current.md).
If that task changes, reconcile this design before implementation.

## Problem and capability contract

Callers need alternate names for existing catalog entries. Extend the constructor
to `Catalog(mapping, aliases=None)`, where aliases is an ordered list of
`(alias, canonical_name)` pairs. Keep `resolve(key)` as the lookup interface.

- Omitted aliases, `None`, and an empty list preserve canonical-only behavior.
- Canonical names retain their values. An alias returns the same value object
  as its canonical target, including mutable values.
- Unknown names raise the normal `KeyError` for the requested key.
- Each target must exist in the canonical mapping. Aliases cannot target other
  aliases, whether declared earlier or later.
- Reject canonical-name collisions, duplicate alias declarations (even with
  the same target), and dangling targets with `ValueError`. Its string must
  contain the offending alias name; complete wording is not prescribed.
- Validate pairs in input order and stop at the first invalid pair. Within one
  pair, the reason chosen is not contractual, since its alias name is the same.
- Construction must not mutate the caller's mapping or alias list, including
  when validation fails.

Names are nonempty strings. Malformed pairs and other name types are outside
scope. No third-party dependencies are needed.

## Repository reality and current slice

`src/catalog.py` currently copies `mapping` with `dict(mapping)` and resolves
directly through that copy. Values are shared rather than deep-copied.
`tests/test_catalog.py` has two baseline unittest cases: canonical lookup and
unknown-key failure. README.md documents this canonical-only implementation.

This first context creates design and checkpoint files only. Source, existing
tests, README, and the task channel remain unchanged. Implementation, added
tests, and documentation of shipped alias behavior belong to the next context,
subject to its then-current task instructions.

## Fixed decisions and proposed implementation

1. Retain the existing shallow `dict(mapping)` snapshot for canonical entries.
2. Build a separate private alias-to-canonical-name dictionary. Iterate the
   supplied pairs directly, using an empty sequence for `None`.
3. For each pair, check that its alias is absent from canonical keys and from
   aliases already accepted, and that its target is in canonical keys. Raise
   `ValueError` containing that alias on the first failure. Add the pair only
   after it passes these checks.
4. Resolve a canonical key directly. Otherwise, translate an alias once, then
   index the canonical mapping. For unknown keys, fall through to canonical
   mapping indexing with the original key so normal `KeyError` behavior remains.

Keep the canonical-key set distinct from accepted aliases during validation;
adding aliases into the canonical mapping would accidentally permit chains.
Do not first convert the input list to a dictionary: that loses duplicate
declarations and may obscure which pair fails first.

The private representation is a proposal, not a new public interface. Expected
construction cost is O(canonical entries + alias pairs), with O(1) average
lookup. No sorting, recursive resolution, normalization, or deep copying.

## Boundary Ownership

Producer: callers supply canonical entries and ordered alias declarations.
Consumer: callers of `Catalog.resolve`.
Owning surface: `Catalog` owns its copied lookup state and validates aliases at
construction. Callers retain their original containers and shared value objects.
Verdict: `single-surface` (inline reviewer judgment, no configured probe).

## Success criteria and acceptance checks

Verification type: `unit`. Add a separate `tests/test_catalog_aliases.py` using
standard-library unittest; keep `tests/test_catalog.py` intact. Assert observable
API behavior, not private field names. The following checks are planned, not run:

| Criterion | Planned check |
| --- | --- |
| Constructor compatibility | Omitted aliases, `None`, and `[]` each preserve canonical lookup and unknown-name failure. |
| Alias resolution | With `[("reading", "books")]`, both names resolve to the same list object, using `assertIs`. |
| Multiple aliases | Two distinct aliases may point to `books`; another may point to `music`. All resolve correctly. |
| Unknown-name compatibility | With aliases configured, `resolve("missing")` raises `KeyError` with `args == ("missing",)`. |
| Canonical collision | `[("books", "music")]` raises `ValueError` whose string contains `books`. |
| Duplicate declarations | Both repeated identical pairs and the same alias with different canonical targets fail and name that alias. |
| Dangling target | `[("orphan", "absent")]` fails and names `orphan`. An alias on an empty canonical mapping fails too. |
| Chains forbidden in either order | `[("reading", "books"), ("shortcut", "reading")]` fails for `shortcut`; reversing the list also fails for `shortcut`. |
| Self-reference | `[("loop", "loop")]` fails for `loop` when it is not canonical. |
| First invalid pair wins | Use valid prefixes and multiple invalid pairs; assert the first invalid alias is named and later invalid aliases are not. Include an early dangling pair before a later collision, and an early duplicate before a later dangling pair. |
| Input preservation | Snapshot mapping, alias list, and value identity; assert unchanged after successful construction and after failure following a valid prefix. |
| Snapshot compatibility | Replacing/adding keys in the caller mapping after construction does not change the catalog snapshot; mutating a shared value remains visible through canonical and alias lookup. Editing the caller alias list after construction does not change the catalog's accepted aliases. |

Run `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`.
The two existing tests must continue to pass alongside the added alias tests.

## Critique and remaining uncertainty

Inline bounded review for this small, local contract:

- Likely misread: checking a target against combined canonical and alias keys
  permits chains. The two declaration-order tests detect that mistake.
- Hidden sequencing: grouping validation by failure type across the whole list
  violates first-invalid-pair order. Mixed-failure sequences detect it.
- Overstated acceptance: baseline tests prove no alias behavior. The added
  checks must pass before documentation describes aliases as shipped.
- Ownership risk: mutating input containers or deep-copying values changes the
  current boundary. Input snapshots and identity checks cover it.

Probe questions: none block implementation. Exact error wording and private
field names remain implementer choices constrained by the public contract.
Deferred decisions/non-goals: alias chains, malformed-input validation, alternate
input formats, new mutation APIs, and richer diagnostics. Do not add them under
revision 1. A later task revision can change this scope.

## Canonical artifact and next slice

`.task/current.md` remains authoritative. This document is the living design;
[the checkpoint](../CHECKPOINT.md) records phase status and restart instructions.
The next context should read the current task first, reconcile requirements,
then implement constructor validation and lookup, add the planned tests, update
README and this design to match actual behavior, and run the full unittest suite.
