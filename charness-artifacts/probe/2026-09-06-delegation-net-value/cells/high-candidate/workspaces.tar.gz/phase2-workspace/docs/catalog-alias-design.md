# Catalog aliases design

Contract: revision 2 of [the authoritative task](../.task/current.md).
Implementation and verification status are recorded in [the checkpoint](../CHECKPOINT.md).

## Revision reconciliation

Revision 2 authorizes implementation. It supersedes revision 1's ban on chains,
single-pass validation, and design-only phase boundary. Alias-to-alias chains,
including forward references, are required. `canonical_key(name)` is now public.
Structural errors across all declarations take precedence over resolution errors.

## Public contract

`Catalog(mapping, aliases=None)` accepts an ordered list of `(alias, target_name)`
pairs. Omitted aliases, `None`, and `[]` preserve canonical-only behavior.
`resolve(name)` returns the terminal canonical value; `canonical_key(name)`
returns the terminal canonical name. Canonical input returns itself. Both methods
raise `KeyError` with the requested name for unknown input.

First scan declarations in order for canonical-name collisions and duplicate
alias names. Raise `ValueError` containing the first invalid alias name.
Only after this scan succeeds, resolve declared aliases in order. A cycle,
self-cycle, or missing terminal target raises `ValueError` naming the initiating
alias of the first failed chain, even if the fault is several links away.
Unused canonical entries are valid.

The catalog shallow-copies the mapping and snapshots alias relationships.
Construction, including failed validation, leaves caller containers untouched.
Values retain identity. Later edits to the input containers do not change name
resolution, while mutations to shared value objects remain visible.
Names are nonempty strings; malformed pairs and other name types are outside
scope. No third-party dependencies or new mutation APIs are needed.

## Algorithm and ownership

1. Copy canonical entries using `dict(mapping)`.
2. Build an ordered alias-to-target dictionary while checking collisions and
   duplicates; do not convert the declaration list directly into a dictionary.
3. Walk chains iteratively in declaration order. Keep a per-walk path and set
   to detect cycles. Stop at a canonical key or an already resolved alias.
   Cache the terminal canonical key for every alias on a successful path.
   Error diagnostics retain the initiating alias throughout each walk.
4. `canonical_key` checks canonical membership, then indexes the resolved alias
   dictionary. `resolve` indexes the canonical snapshot using `canonical_key`.

The Catalog owns validation and copied lookup state. Callers own original
containers and shared values. Forward references work because all declarations
are available before traversal. Iteration avoids recursion depth limits, and
caching shared suffixes gives expected O(canonical entries + aliases)
construction time and storage, with expected O(1) lookups.

## Acceptance and inline review

Keep `tests/test_catalog.py` intact and add public-API tests in
`tests/test_catalog_aliases.py` for:

- constructor compatibility, unused keys, empty catalogs, and unknown-name errors;
- direct aliases, both chain orders, shared suffixes, and value identity;
- collisions and duplicate declarations (identical and different targets);
- dangling chains, self-cycles, multi-node cycles, and tails entering cycles;
- structural precedence over earlier broken chains, declaration order within
  both stages, and initiating-alias diagnostics;
- input preservation on success and both failure stages, snapshot behavior,
  and a chain longer than Python's usual recursion limit.

Review risks: a one-pass resolver breaks forward references and structural
precedence; a visited set shared across walks rejects valid shared suffixes;
reporting the failing node loses initiating-alias attribution; recursion imposes
an unnecessary chain limit. The algorithm and acceptance cases address these
risks without exposing private state or prescribing exact error wording.

Verification command:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```
