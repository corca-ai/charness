import unittest

from src.catalog import Catalog


class CatalogAliasTests(unittest.TestCase):
    def assert_unknown(self, catalog, name):
        for lookup in (catalog.resolve, catalog.canonical_key):
            with self.subTest(lookup=lookup.__name__, name=name):
                with self.assertRaises(KeyError) as error:
                    lookup(name)
                self.assertEqual(error.exception.args, (name,))

    def assert_invalid(self, aliases, expected, mapping=None):
        if mapping is None:
            mapping = {"books": [], "music": []}
        original_mapping = dict(mapping)
        original_aliases = list(aliases)
        with self.assertRaises(ValueError) as error:
            Catalog(mapping, aliases)
        self.assertIn(expected, str(error.exception))
        self.assertEqual(mapping, original_mapping)
        self.assertEqual(aliases, original_aliases)
        for name, value in original_mapping.items():
            self.assertIs(mapping[name], value)

    def test_constructor_compatibility(self):
        value = []
        for args in ((), (None,), ([],)):
            with self.subTest(args=args):
                catalog = Catalog({"books": value}, *args)
                self.assertIs(catalog.resolve("books"), value)
                self.assertEqual(catalog.canonical_key("books"), "books")
                self.assert_unknown(catalog, "missing")
                self.assert_unknown(Catalog({}, *args), "missing")

    def test_direct_aliases_and_unused_canonical_keys(self):
        books, music = [], []
        catalog = Catalog(
            {"books": books, "music": music, "unused": None},
            [("reading", "books"), ("novels", "books"), ("listening", "music")],
        )
        for name in ("books", "reading", "novels"):
            self.assertIs(catalog.resolve(name), books)
            self.assertEqual(catalog.canonical_key(name), "books")
        self.assertIs(catalog.resolve("listening"), music)
        self.assertEqual(catalog.canonical_key("listening"), "music")
        self.assertIsNone(catalog.resolve("unused"))
        self.assertEqual(catalog.canonical_key("unused"), "unused")
        self.assert_unknown(catalog, "missing")

    def test_chains_in_both_orders_and_shared_suffixes(self):
        declarations = [("shortcut", "reading"), ("reading", "books")]
        value = []
        for aliases in (declarations, list(reversed(declarations))):
            with self.subTest(aliases=aliases):
                catalog = Catalog({"books": value}, aliases + [("other", "reading")])
                for name in ("books", "reading", "shortcut", "other"):
                    self.assertIs(catalog.resolve(name), value)
                    self.assertEqual(catalog.canonical_key(name), "books")

    def test_long_forward_chain(self):
        aliases = [(f"alias_{i}", f"alias_{i + 1}") for i in range(2000)]
        aliases.append(("alias_2000", "books"))
        value = []
        catalog = Catalog({"books": value}, aliases)
        for name, _ in aliases:
            self.assertEqual(catalog.canonical_key(name), "books")
            self.assertIs(catalog.resolve(name), value)

    def test_structural_errors(self):
        cases = [
            ([("books", "music")], "books"),
            ([("repeat", "books"), ("repeat", "books")], "repeat"),
            ([("repeat", "books"), ("repeat", "music")], "repeat"),
            ([("first", "books"), ("first", "music"), ("books", "music")], "first"),
            ([("music", "books"), ("books", "music")], "music"),
        ]
        for aliases, expected in cases:
            with self.subTest(aliases=aliases):
                self.assert_invalid(aliases, expected)

    def test_structural_errors_precede_broken_chains(self):
        for broken in ([("orphan", "absent")], [("loop", "loop")]):
            for invalid, expected in (
                ([("repeat", "books"), ("repeat", "music")], "repeat"),
                ([("books", "music")], "books"),
            ):
                with self.subTest(broken=broken, invalid=invalid):
                    self.assert_invalid(broken + invalid, expected)

    def test_failed_chains_report_first_initiating_alias(self):
        cases = [
            ([("orphan", "absent")], "orphan"),
            ([("start", "middle"), ("middle", "absent")], "start"),
            ([("middle", "absent"), ("start", "middle")], "middle"),
            ([("loop", "loop")], "loop"),
            ([("alpha", "beta"), ("beta", "alpha")], "alpha"),
            ([("entry", "alpha"), ("alpha", "beta"), ("beta", "alpha")], "entry"),
            ([("valid", "books"), ("first", "absent"), ("second", "second")], "first"),
            ([("first", "first"), ("second", "absent")], "first"),
        ]
        for aliases, expected in cases:
            with self.subTest(aliases=aliases):
                self.assert_invalid(aliases, expected)
        self.assert_invalid([("orphan", "absent")], "orphan", mapping={})

    def test_input_preservation_and_snapshot_behavior(self):
        value = ["novel"]
        mapping = {"books": value}
        aliases = [("shortcut", "reading"), ("reading", "books")]
        catalog = Catalog(mapping, aliases)
        self.assertEqual(mapping, {"books": ["novel"]})
        self.assertIs(mapping["books"], value)
        self.assertEqual(aliases, [("shortcut", "reading"), ("reading", "books")])
        mapping["books"] = ["replacement"]
        mapping["new_key"] = []
        aliases[:] = [("new_alias", "new_key")]
        value.append("poetry")
        for name in ("books", "reading", "shortcut"):
            self.assertIs(catalog.resolve(name), value)
            self.assertEqual(catalog.resolve(name), ["novel", "poetry"])
            self.assertEqual(catalog.canonical_key(name), "books")
        self.assert_unknown(catalog, "new_key")
        self.assert_unknown(catalog, "new_alias")


if __name__ == "__main__":
    unittest.main()
