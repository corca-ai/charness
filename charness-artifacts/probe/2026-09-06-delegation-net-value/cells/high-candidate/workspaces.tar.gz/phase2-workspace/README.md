# Catalog

A dependency-free catalog with canonical names and validated alias chains:

```python
from src.catalog import Catalog

catalog = Catalog(
    {"books": ["novel"]},
    aliases=[("shortcut", "reading"), ("reading", "books")],
)
catalog.resolve("shortcut")       # ["novel"]
catalog.canonical_key("shortcut") # "books"
```

`Catalog(mapping, aliases=None)` accepts an ordered list of `(alias, target_name)`
pairs. Aliases can target canonical keys or other aliases, including forward
references. Omitting aliases preserves canonical-only lookup. `resolve(name)`
returns the same value object as the terminal canonical entry;
`canonical_key(name)` returns its key. Unknown names raise `KeyError` in both
methods.

Construction first checks all declarations in order for canonical-name collisions
and duplicate aliases, raising `ValueError` containing the invalid alias name.
It then resolves chains in declaration order. Missing terminal targets and cycles
(including self-cycles) raise `ValueError` containing the initiating alias name of
the first failed chain. Structural errors take precedence over broken chains.
Unused canonical keys are valid.

Inputs are not mutated. Mapping entries and alias relationships are snapshotted;
value objects remain shared. Names are nonempty strings; malformed pairs and
other name types are outside the supported contract.

Run all tests with the standard library:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```

See [the design](docs/catalog-alias-design.md) for the algorithm and acceptance
criteria, and [the checkpoint](CHECKPOINT.md) for recorded verification.
