"""Canonical-key lookup with validated alias chains."""

from __future__ import annotations


class Catalog:
    """Resolve canonical names and aliases against a shallow mapping snapshot."""

    def __init__(self, mapping, aliases=None):
        self._mapping = dict(mapping)
        targets = {}
        # Finish structural validation before following any chain.
        for alias, target in (() if aliases is None else aliases):
            if alias in self._mapping or alias in targets:
                raise ValueError(f"Invalid alias declaration: {alias!r}")
            targets[alias] = target

        self._aliases = {}
        for alias in targets:
            path = []
            seen = set()
            name = alias
            while name not in self._mapping and name not in self._aliases:
                if name in seen or name not in targets:
                    raise ValueError(f"Cannot resolve alias: {alias!r}")
                seen.add(name)
                path.append(name)
                name = targets[name]
            canonical = name if name in self._mapping else self._aliases[name]
            for name in path:
                self._aliases[name] = canonical

    def canonical_key(self, name):
        """Return the terminal canonical key, or raise KeyError for unknown names."""
        if name in self._mapping:
            return name
        return self._aliases[name]

    def resolve(self, key):
        return self._mapping[self.canonical_key(key)]
