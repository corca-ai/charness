# Fresh-context checkpoint

## Boundary and authority

This context completed only design and handoff, as required by revision 1 of
`.task/current.md`. Source and tests have not been edited, and the task file must
remain untouched. The next fresh context should read the then-current task
first: a later revision supersedes this checkpoint and the proposed design.
Do not use external services or install packages. Work only in this workspace.

## Repository findings

- `src/catalog.py`: `Catalog(mapping)` shallow-copies the mapping with `dict`;
  `resolve(key)` directly indexes that snapshot. Alias support is absent.
- `tests/test_catalog.py`: two baseline unittest cases cover canonical lookup
  and unknown-name `KeyError`. Preserve this file intact.
- `README.md`: canonical-only usage and the unittest discovery command.
- No `AGENTS.md` or dependency configuration was found in the workspace scan.
- Initial `git status --short` listed `.task/`, `README.md`, `src/`, and `tests/`
  as untracked. These preexisting files are not newly created task changes.

## Work completed

Added `DESIGN.md` with revision 1's API contract, ordered validation algorithm,
separate canonical and alias dictionaries, ownership semantics, and planned test
coverage. Added this checkpoint. No implementation or new tests were attempted.

Baseline verification: `python3 -m unittest discover -s tests -v` passed both
existing tests. This confirms only the seed behavior, not alias support.

## Next actions

1. Reread `.task/current.md`, applicable repository instructions, `DESIGN.md`,
   source, and tests. Reconcile the design with any task revision before coding.
2. If the then-current boundary permits implementation, implement its contract
   in `src/catalog.py`; revision 1's proposed approach is in `DESIGN.md`.
3. Add tests in a separate file while preserving baseline tests. Adapt the
   planned coverage to the authoritative revision.
4. Run the full unittest suite, document the implemented API in the README, and
   update the design and checkpoint to reflect actual results and remaining work.

No unresolved clarification is needed for revision 1. Implementation is deferred
solely because the first-context boundary explicitly requires it.
