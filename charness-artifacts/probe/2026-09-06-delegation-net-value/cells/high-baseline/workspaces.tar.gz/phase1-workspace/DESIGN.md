# Catalog aliases design

Status: proposed design for `.task/current.md`, revision 1. No alias support has
been implemented. The task file is authoritative; reread it and update this
design if a later revision changes the requirements.

## Public behavior

Extend the constructor to `Catalog(mapping, aliases=None)`. Omitting aliases,
passing `None`, or passing an empty list preserves canonical-only behavior.
Aliases are an ordered list of `(alias, canonical_name)` pairs. Each alias
resolves to the same value object as its canonical target.

Every target must be a key in the canonical mapping. Alias chains are forbidden,
including references to previously declared aliases. Reject canonical-name
collisions, repeated alias declarations (even with the same target), and targets
absent from the canonical mapping. Raise `ValueError` containing the invalid
alias name. Process declarations in input order so the first invalid pair is
reported. The exact message beyond the alias name is not specified.

Retain ordinary dictionary lookup behavior for canonical and unknown names,
including `KeyError` identifying the originally requested unknown name. Never
mutate the caller's mapping or alias list. Names are nonempty strings; malformed
pair shapes and other name types are outside scope.

## Implementation plan

Keep the existing shallow canonical snapshot, `self._mapping = dict(mapping)`.
Build a separate alias-to-canonical dictionary during construction. For each
pair, check whether the alias is a canonical key, whether it has already been
declared, and whether the target exists in the canonical snapshot. Raise on an
invalid pair before recording it. Use membership checks, not truthiness of
values. Validate only against the canonical snapshot for target existence; this
prevents both forward and backward alias chains without graph traversal.

Do not retain or modify the input alias list. A separate alias dictionary keeps
canonical membership distinct from alias membership and permits constant-time
lookup. `resolve` can translate a known alias to its canonical key and then use
the existing dictionary indexing operation. Unknown names pass through unchanged
to preserve their `KeyError`. Values remain shared by reference, as they are in
the current shallow copy; do not introduce deep copies.

Construction takes O(C + A) time and storage for C canonical names and A aliases;
lookup takes expected O(1) time. No dependencies are needed.

## Planned verification

Keep `tests/test_catalog.py` intact and add alias coverage in a new test file:

- Default, explicit `None`, and empty aliases preserve canonical resolution and
  unknown-name `KeyError`, including its arguments.
- One and several aliases resolve correctly, with multiple aliases allowed for
  the same target. Mutable values have identical object identity through aliases
  and canonical names. Falsey canonical values also resolve correctly.
- A canonical-name collision, duplicate alias with either the same or a different
  target, and dangling target each raise `ValueError` naming the invalid alias.
- Forward and backward alias chains, self references, and cycles are rejected
  because their targets are not canonical keys.
- Inputs with several invalid declarations report the first invalid pair;
  include a valid prefix and varied invalidity kinds to catch reordered checks
  across declarations.
- Successful and failed construction leave the supplied mapping and alias list
  unchanged. Subsequent changes to the caller's mapping or alias list do not
  alter the catalog's stored bindings, preserving the snapshot design.

Run `python3 -m unittest discover -s tests -v` after implementation. Update the
README with the public alias API and validation behavior once implemented.
