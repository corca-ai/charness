# Catalog aliases design

Status: implemented for `.task/current.md`, revision 2. This supersedes the
revision 1 proposal that prohibited alias chains.

## Public behavior

`Catalog(mapping, aliases=None)` shallow-copies canonical bindings. Aliases are
an ordered list of `(alias, target_name)` pairs; targets may be canonical names
or other aliases, including forward references. Omitted, `None`, and empty
aliases preserve canonical-only behavior. Unused canonical keys are valid.

`canonical_key(name)` returns a canonical input unchanged or an alias's terminal
canonical key. `resolve(name)` returns the value at that key, preserving value
identity. Both methods raise `KeyError` with the requested unknown name.

## Validation and implementation

First scan every declaration in order into a separate target dictionary. Reject
canonical-name collisions and duplicate aliases with `ValueError` naming the
invalid alias. This entire structural stage precedes chain resolution, so a
later duplicate takes precedence over an earlier dangling chain or cycle.

Then resolve declared aliases in input order. Walk each unresolved chain
iteratively, maintaining its path and a set of visited names. A repeated name or
missing target raises `ValueError` naming the initiating alias, even when the
fault occurs farther along the chain. Self-cycles are rejected in the same way.
Stop at a canonical key or an already resolved alias, and cache the terminal
canonical key for every alias on the path. Iteration supports chains longer
than Python's recursion limit; caching avoids repeated traversal of shared tails.

The canonical snapshot and resolved alias dictionary are independent of the
caller's containers. Construction never modifies inputs, even on failure.
Later container edits cannot change stored bindings; mutable values remain
shared by reference. Names are nonempty strings; malformed pairs and other
name types are outside scope. No third-party dependencies are used.

Construction takes expected O(C + A) time and storage for C canonical names and
A aliases; lookup takes expected O(1) time.

## Verification

Preserve `tests/test_catalog.py` and add coverage in `tests/test_catalog_aliases.py`
for optional aliases, canonical keys, unknown-name errors, value identity and
falsey values, forward/backward/shared chains, long chains, declaration errors,
cycles, dangling chains, error ordering, and input ownership on success/failure.
Run `python3 -m unittest discover -s tests -v`; the completion record is in
`CHECKPOINT.md`.
