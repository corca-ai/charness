import unittest

from src.catalog import Catalog


class CatalogAliasTests(unittest.TestCase):
    def test_optional_aliases_and_unknown_names(self):
        for catalog in (Catalog({'books': 1}), Catalog({'books': 1}, None),
                        Catalog({'books': 1}, []),
                        Catalog({'books': 1}, [('reading', 'books')])):
            with self.subTest(catalog=catalog):
                self.assertEqual(catalog.resolve('books'), 1)
                self.assertEqual(catalog.canonical_key('books'), 'books')
                for lookup in (catalog.resolve, catalog.canonical_key):
                    with self.assertRaises(KeyError) as error:
                        lookup('unknown')
                    self.assertEqual(error.exception.args, ('unknown',))

    def test_forward_backward_and_shared_chains(self):
        value = []
        catalog = Catalog({'books': value, 'unused': 7}, [
            ('reading', 'fiction'), ('fiction', 'books'),
            ('novels', 'fiction'), ('stories', 'reading'),
        ])
        for name in ('books', 'reading', 'fiction', 'novels', 'stories'):
            with self.subTest(name=name):
                self.assertIs(catalog.resolve(name), value)
                self.assertEqual(catalog.canonical_key(name), 'books')
        self.assertEqual(catalog.resolve('unused'), 7)
        self.assertEqual(catalog.canonical_key('unused'), 'unused')

    def test_falsey_values(self):
        for value in (None, False, 0, '', [], {}):
            with self.subTest(value=value):
                catalog = Catalog({'key': value}, [('alias', 'key')])
                self.assertIs(catalog.resolve('alias'), value)
                self.assertEqual(catalog.canonical_key('alias'), 'key')

    def test_long_chain(self):
        aliases = [(f'a{i}', f'a{i + 1}') for i in range(5000)]
        aliases.append(('a5000', 'key'))
        catalog = Catalog({'key': 42}, aliases)
        self.assertEqual(catalog.resolve('a0'), 42)
        self.assertEqual(catalog.canonical_key('a2500'), 'key')

    def assert_invalid(self, aliases, initiating, mapping=None):
        with self.assertRaises(ValueError) as error:
            Catalog({'key': 1} if mapping is None else mapping, aliases)
        self.assertIn(initiating, str(error.exception))

    def test_structural_errors(self):
        for aliases, invalid in [
            ([('key', 'missing')], 'key'),
            ([('duplicate', 'key'), ('duplicate', 'key')], 'duplicate'),
            ([('duplicate', 'key'), ('duplicate', 'missing')], 'duplicate'),
            ([('first', 'key'), ('first', 'key'), ('key', 'key')], 'first'),
        ]:
            with self.subTest(aliases=aliases):
                self.assert_invalid(aliases, invalid)

    def test_structural_stage_precedes_chain_errors(self):
        for target in ('missing', 'early'):
            for suffix, invalid in [
                ([('duplicate', 'key'), ('duplicate', 'key')], 'duplicate'),
                ([('key', 'key')], 'key'),
            ]:
                with self.subTest(target=target, suffix=suffix):
                    self.assert_invalid([('early', target)] + suffix, invalid)

    def test_failed_chains_identify_initiator(self):
        for aliases in [
            [('origin', 'missing')],
            [('origin', 'middle'), ('middle', 'missing')],
            [('origin', 'origin')],
            [('origin', 'middle'), ('middle', 'origin')],
            [('origin', 'middle'), ('middle', 'tail'), ('tail', 'middle')],
        ]:
            with self.subTest(aliases=aliases):
                self.assert_invalid(aliases, 'origin')

    def test_first_failed_chain_in_declaration_order(self):
        for first_target, later_target in [('missing', 'later'),
                                            ('first', 'absent')]:
            self.assert_invalid([
                ('valid', 'key'), ('first', first_target),
                ('later', later_target),
            ], 'first')

    def test_empty_mapping(self):
        catalog = Catalog({})
        for lookup in (catalog.resolve, catalog.canonical_key):
            with self.assertRaises(KeyError):
                lookup('unknown')
        self.assert_invalid([('origin', 'missing')], 'origin', {})

    def test_inputs_unchanged_and_bindings_snapshotted(self):
        value = []
        mapping = {'key': value}
        aliases = [('alias', 'key')]
        catalog = Catalog(mapping, aliases)
        self.assertEqual(mapping, {'key': []})
        self.assertEqual(aliases, [('alias', 'key')])
        mapping.clear()
        aliases[:] = [('replacement', 'missing')]
        value.append('shared')
        self.assertIs(catalog.resolve('alias'), value)
        self.assertIs(catalog.resolve('key'), value)
        self.assertEqual(catalog.resolve('alias'), ['shared'])
        self.assertEqual(catalog.canonical_key('alias'), 'key')
        with self.assertRaises(KeyError):
            catalog.resolve('replacement')

    def test_failed_construction_preserves_inputs(self):
        for aliases in [
            [('alias', 'missing')], [('alias', 'alias')],
            [('alias', 'key'), ('alias', 'key')], [('key', 'key')],
        ]:
            with self.subTest(aliases=aliases):
                value = []
                mapping = {'key': value}
                before = list(aliases)
                with self.assertRaises(ValueError):
                    Catalog(mapping, aliases)
                self.assertEqual(mapping, {'key': []})
                self.assertIs(mapping['key'], value)
                self.assertEqual(aliases, before)


if __name__ == '__main__':
    unittest.main()
