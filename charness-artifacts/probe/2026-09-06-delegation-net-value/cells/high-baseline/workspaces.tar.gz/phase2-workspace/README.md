# Catalog

A dependency-free catalog with canonical names and alias chains:

```python
from src.catalog import Catalog

catalog = Catalog(
    {"books": ["novel"], "music": ["jazz"]},
    aliases=[("reading", "fiction"), ("fiction", "books")],
)
catalog.resolve("reading")       # ["novel"]
catalog.canonical_key("reading") # "books"
catalog.canonical_key("music")   # "music"
```

Aliases are optional and support forward references. Both lookup methods raise
`KeyError` for unknown names. The catalog snapshots the input bindings without
modifying the mapping or alias list; values are shared by reference.

Construction first checks all declarations in order for canonical-name
collisions and duplicate aliases, raising `ValueError` naming the invalid alias.
It then resolves chains in declaration order. Cycles (including self-cycles) and
missing targets raise `ValueError` naming the initiating alias of the first
failed chain. Structural errors take precedence over chain errors.

Run all tests with:

```text
python3 -m unittest discover -s tests -v
```
