"""A minimal canonical-key catalog used by the consumer fixture."""

from __future__ import annotations


class Catalog:
    """Resolve values by canonical keys and their aliases."""

    def __init__(self, mapping, aliases=None):
        self._mapping = dict(mapping)
        self._aliases = {}
        self._resolved_aliases = {}

        if aliases is not None:
            # Scan every declaration before resolving any target. This keeps
            # structural errors deterministic even when a target is dangling.
            for alias, target in aliases:
                if alias in self._mapping or alias in self._aliases:
                    raise ValueError(f"invalid alias {alias!r}")
                self._aliases[alias] = target

            for alias in self._aliases:
                self._resolve_alias(alias)

    def _resolve_alias(self, alias):
        """Return and cache an alias's terminal canonical key."""
        if alias in self._resolved_aliases:
            return self._resolved_aliases[alias]

        path = []
        seen = set()
        current = alias
        while current in self._aliases:
            if current in self._resolved_aliases:
                terminal = self._resolved_aliases[current]
                break
            if current in seen:
                raise ValueError(f"invalid alias {alias!r}")
            seen.add(current)
            path.append(current)
            current = self._aliases[current]
        else:
            terminal = current

        if terminal not in self._mapping:
            raise ValueError(f"invalid alias {alias!r}")

        for name in reversed(path):
            self._resolved_aliases[name] = terminal
        return terminal

    def canonical_key(self, name):
        """Return the canonical key corresponding to *name*."""
        if name in self._mapping:
            return name
        if name in self._aliases:
            return self._resolve_alias(name)
        # Preserve the ordinary mapping lookup and its KeyError argument.
        return self._mapping[name]

    def resolve(self, key):
        return self._mapping[self.canonical_key(key)]
