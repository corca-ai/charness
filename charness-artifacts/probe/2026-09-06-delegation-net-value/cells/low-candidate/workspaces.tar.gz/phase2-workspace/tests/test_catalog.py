import unittest

from src.catalog import Catalog


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.catalog = Catalog({"books": ["novel"], "music": ["jazz"]})

    def test_resolves_existing_canonical_keys(self):
        self.assertEqual(self.catalog.resolve("books"), ["novel"])
        self.assertEqual(self.catalog.resolve("music"), ["jazz"])

    def test_unknown_key_raises_key_error(self):
        with self.assertRaises(KeyError):
            self.catalog.resolve("missing")

    def test_alias_resolves_to_canonical_value_and_key(self):
        catalog = Catalog({"books": ["novel"]}, [("reading", "books")])

        self.assertEqual(catalog.resolve("reading"), ["novel"])
        self.assertEqual(catalog.canonical_key("reading"), "books")

    def test_alias_chains_support_forward_references(self):
        catalog = Catalog(
            {"books": ["novel"]},
            [("reader", "reading"), ("reading", "books")],
        )

        self.assertEqual(catalog.resolve("reader"), ["novel"])
        self.assertEqual(catalog.canonical_key("reader"), "books")

    def test_canonical_key_returns_canonical_input(self):
        self.assertEqual(self.catalog.canonical_key("books"), "books")

    def test_aliases_none_preserves_one_argument_constructor(self):
        self.assertEqual(Catalog({"books": ["novel"]}).resolve("books"), ["novel"])

    def test_unknown_canonical_key_raises_key_error_with_requested_name(self):
        with self.assertRaises(KeyError) as context:
            self.catalog.canonical_key("missing")

        self.assertEqual(context.exception.args, ("missing",))

    def test_canonical_name_collision_mentions_alias(self):
        with self.assertRaisesRegex(ValueError, "reading"):
            Catalog({"reading": []}, [("reading", "books")])

    def test_duplicate_alias_is_found_before_resolution(self):
        with self.assertRaisesRegex(ValueError, "reading"):
            Catalog({}, [("early", "missing"), ("reading", "books"), ("reading", "other")])

    def test_missing_terminal_target_mentions_initiating_alias(self):
        with self.assertRaisesRegex(ValueError, "early"):
            Catalog({}, [("early", "later"), ("later", "missing")])

    def test_cycle_mentions_initiating_alias(self):
        with self.assertRaisesRegex(ValueError, "first"):
            Catalog({}, [("first", "second"), ("second", "first")])

    def test_self_cycle_is_invalid(self):
        with self.assertRaisesRegex(ValueError, "loop"):
            Catalog({}, [("loop", "loop")])

    def test_unused_canonical_keys_are_valid(self):
        catalog = Catalog({"books": [], "unused": []}, [("reading", "books")])

        self.assertEqual(catalog.canonical_key("unused"), "unused")

    def test_constructor_and_resolution_do_not_mutate_inputs(self):
        mapping = {"books": ["novel"]}
        aliases = [("reader", "books"), ("reading", "reader")]
        original_mapping = dict(mapping)
        original_aliases = list(aliases)

        catalog = Catalog(mapping, aliases)
        catalog.resolve("reading")

        self.assertEqual(mapping, original_mapping)
        self.assertEqual(aliases, original_aliases)

    def test_mapping_is_snapshotted_at_construction(self):
        mapping = {"books": ["novel"]}
        catalog = Catalog(mapping, [("reading", "books")])
        mapping["books"] = ["poetry"]
        mapping["new"] = ["music"]

        self.assertEqual(catalog.resolve("books"), ["novel"])
        with self.assertRaises(KeyError):
            catalog.resolve("new")


if __name__ == "__main__":
    unittest.main()
