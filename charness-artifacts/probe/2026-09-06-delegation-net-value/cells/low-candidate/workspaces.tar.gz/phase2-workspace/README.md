# Catalog fixture

This dependency-free seed exposes a deliberately small public API:

```python
from src.catalog import Catalog

catalog = Catalog({"books": ["novel"]})
catalog.resolve("books")
```

`Catalog(mapping, aliases=None)` performs canonical-key lookup. Each alias is
an `(alias, target_name)` pair and may target another alias; lookup follows the
chain to its terminal canonical key. `canonical_key(name)` exposes that
terminal key. Unknown names raise the normal `KeyError`, while collisions,
duplicates, missing targets, and cycles raise `ValueError` naming the initiating
alias.

Run the baseline with:

```text
python3 -m unittest discover -s tests -v
```
