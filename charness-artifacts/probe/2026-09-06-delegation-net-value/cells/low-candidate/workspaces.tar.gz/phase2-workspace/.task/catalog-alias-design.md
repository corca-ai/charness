# Catalog aliases: design checkpoint

Status: implemented checkpoint for revision 2. `.task/current.md` remains
authoritative.

## Problem

`Catalog` currently resolves only canonical mapping keys. The next slice adds
optional aliases while preserving canonical lookup and the ordinary `KeyError`
for unknown names.

## Capability contract

`Catalog(mapping, aliases=None)` accepts an ordered iterable of alias pairs when
provided. An alias resolves to the value stored under its canonical target.
Targets may be canonical keys or other aliases, including aliases declared
later in the ordered input.

The constructor performs structural validation for all pairs first, rejecting
with `ValueError` the first invalid declaration in input order when:

- the alias is also a canonical mapping key;
- the alias was already declared; or
- Only after that scan succeeds does it resolve each declaration in input
  order. A missing terminal target or cycle raises `ValueError` containing the
  initiating alias for the first failed chain.

Each such error message must contain the invalid alias name. Pair shape and
non-string-name handling are outside this revision's contract.

## Fixed decisions

- Keep the public constructor compatible: `aliases` defaults to `None`.
- Snapshot the caller's mapping with `dict(mapping)` as today; do not mutate it.
- Consume aliases only to build a private alias-to-canonical lookup; do not
  mutate the caller's alias list (or any pair objects).
- Scan all pairs for canonical-name collisions and duplicate alias declarations
  before resolving any target. This ensures an early dangling chain does not
  hide a later duplicate declaration.
- Store declared alias targets privately and resolve chains to cached terminal
  canonical keys, detecting self-cycles and longer cycles.
- Leave unknown-name behavior delegated to the mapping lookup so the raised
  exception remains `KeyError` with the requested unknown key.
- No third-party dependencies and no changes to the existing baseline tests.

## Non-goals

- No normalization, case folding, or whitespace policy beyond the stated
  nonempty-string precondition.
- No public mutation API for aliases.
- No special handling contract for malformed pair shapes or other name types.

## Planned acceptance checks

The implementation context should add unit tests for:

1. canonical keys still resolve unchanged;
2. one alias resolves to its canonical value;
3. multiple aliases preserve their declared targets and values;
4. `aliases=None` preserves the one-argument constructor;
5. unknown canonical and unknown alias-like names raise `KeyError`;
6. canonical-key collisions raise `ValueError` mentioning the alias;
7. duplicate alias declarations raise `ValueError` mentioning the alias;
8. dangling targets raise `ValueError` mentioning the alias;
9. an earlier invalid pair wins over later invalid pairs;
10. alias targets that are themselves aliases resolve, including forward
    references;
11. self-cycles and longer cycles raise `ValueError` naming the initiator;
12. mutating the original mapping after construction does not alter the
    catalog, and constructing/resolving does not mutate the alias list.

Verification type: `unit`, using the repository's existing
`python3 -m unittest discover -s tests -v` command.

## Boundary ownership

- `src/catalog.py` owns copying the mapping, validating aliases, storing the
  private alias index, and resolving names.
- `tests/test_catalog.py` owns executable behavior checks and must retain the
  baseline tests.
- `README.md` should be updated in the implementation context to document the
  public two-argument form and chained-target validation rule.

## Completion evidence

- Implemented `Catalog(mapping, aliases=None)`, `canonical_key(name)`, chained
  alias resolution, two-stage validation, cycle detection, and input
  immutability behavior in `src/catalog.py`.
- Preserved the baseline tests and added revision-2 coverage in
  `tests/test_catalog.py`.
- Updated `README.md` with the public alias and canonical-key behavior.
- Verification: `python3 -m unittest discover -s tests -v` — 15 tests passed.

Non-claims: malformed pair shapes and non-string names remain outside scope;
no third-party dependencies or external services were used.

Canonical artifact: this checkpoint plus `.task/current.md` (the latter remains
authoritative and must not be edited).
