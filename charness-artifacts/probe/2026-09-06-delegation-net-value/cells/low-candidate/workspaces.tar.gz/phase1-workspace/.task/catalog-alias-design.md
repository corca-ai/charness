# Catalog aliases: design checkpoint

Status: design-only checkpoint for revision 1. Source and tests are intentionally
unchanged in this context.

## Problem

`Catalog` currently resolves only canonical mapping keys. The next slice adds
optional aliases while preserving canonical lookup and the ordinary `KeyError`
for unknown names.

## Capability contract

`Catalog(mapping, aliases=None)` accepts an ordered iterable of alias pairs when
provided. An alias resolves to the value stored under its canonical target.
Targets are direct canonical mapping keys; alias-to-alias chains are invalid.

The constructor rejects, with `ValueError`, the first invalid pair in input
order when:

- the alias is also a canonical mapping key;
- the alias was already declared; or
- the target is not a canonical mapping key.

Each such error message must contain the invalid alias name. Pair shape and
non-string-name handling are outside this revision's contract.

## Fixed decisions

- Keep the public constructor compatible: `aliases` defaults to `None`.
- Snapshot the caller's mapping with `dict(mapping)` as today; do not mutate it.
- Consume aliases only to build a private alias-to-canonical lookup; do not
  mutate the caller's alias list (or any pair objects).
- Validate each pair before accepting the next one. Within a pair, check
  canonical-name collision, duplicate alias declaration, then dangling target.
  This gives deterministic errors when a pair violates more than one rule.
- Store only direct alias targets. Resolution first recognizes an alias and then
  performs the normal mapping lookup against its canonical target.
- Leave unknown-name behavior delegated to the mapping lookup so the raised
  exception remains `KeyError` with the requested unknown key.
- No third-party dependencies and no changes to the existing baseline tests.

## Non-goals

- No alias chaining or recursive resolution.
- No normalization, case folding, or whitespace policy beyond the stated
  nonempty-string precondition.
- No public mutation API for aliases.
- No special handling contract for malformed pair shapes or other name types.

## Planned acceptance checks

The implementation context should add unit tests for:

1. canonical keys still resolve unchanged;
2. one alias resolves to its canonical value;
3. multiple aliases preserve their declared targets and values;
4. `aliases=None` preserves the one-argument constructor;
5. unknown canonical and unknown alias-like names raise `KeyError`;
6. canonical-key collisions raise `ValueError` mentioning the alias;
7. duplicate alias declarations raise `ValueError` mentioning the alias;
8. dangling targets raise `ValueError` mentioning the alias;
9. an earlier invalid pair wins over later invalid pairs;
10. alias targets that are themselves aliases are rejected;
11. mutating the original mapping after construction does not alter the
    catalog, and constructing/resolving does not mutate the alias list.

Verification type: `unit`, using the repository's existing
`python3 -m unittest discover -s tests -v` command.

## Boundary ownership

- `src/catalog.py` owns copying the mapping, validating aliases, storing the
  private alias index, and resolving names.
- `tests/test_catalog.py` owns executable behavior checks and must retain the
  baseline tests.
- `README.md` should be updated in the implementation context to document the
  public two-argument form and the direct-target validation rule.

## Open probe for implementation

Confirm the exact `KeyError` key produced by the chosen lookup expression for
an unknown name, and add a regression assertion if it differs from the current
`self._mapping[key]` behavior. The simplest expected implementation is a
single-level alias lookup followed by `self._mapping[target]`.

## First implementation slice for the next context

Update `Catalog.__init__` to accept `aliases=None`, copy the mapping as it does
today, validate aliases in order into a new private dictionary, and update
`resolve` for one-level alias lookup. Then add the planned unit coverage,
update the README, and run the baseline plus new tests.

Canonical artifact: this checkpoint plus `.task/current.md` (the latter remains
authoritative and must not be edited).
