# Catalog fixture

This dependency-free seed exposes a deliberately small public API:

```python
from src.catalog import Catalog

catalog = Catalog({"books": ["novel"]})
catalog.resolve("books")
```

`Catalog(mapping)` performs canonical-key lookup. An unknown key raises the
normal `KeyError`. The seed does not contain alias support or a generated
specification; those belong to the later journey contexts.

## Alias design checkpoint

The next implementation revision extends the constructor to
`Catalog(mapping, aliases=None)`. The canonical mapping remains the source of
truth: it is copied once, and each alias resolves through its canonical target
to the same stored value. The lookup path should preserve ordinary dictionary
behavior for canonical names and unknown names, including `KeyError`.

Alias validation will be performed in the input order. For each `(alias,
canonical_name)` pair, reject with `ValueError` (including the invalid alias
name in the message) when the alias is a canonical key, the alias was already
declared, or the target is not a canonical mapping key. Targets are checked
only against canonical keys, so alias chains are not accepted. `None` means no
aliases. The constructor must copy caller-owned mapping/alias data rather than
mutating either input.

### Durable next actions

1. Add focused tests for successful alias lookup, `None`/empty aliases,
   canonical and unknown lookup compatibility, each validation failure, first
   invalid pair ordering, alias-chain rejection, and input immutability.
2. Implement the constructor and lookup using an internal alias index or a
   combined lookup table while retaining the copied canonical mapping.
3. Run the existing and new unittest suite, then update this section if the
   final implementation details differ.

Run the baseline with:

```text
python3 -m unittest discover -s tests -v
```
