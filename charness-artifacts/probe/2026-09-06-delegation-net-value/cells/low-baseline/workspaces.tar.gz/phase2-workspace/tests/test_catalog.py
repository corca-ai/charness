import unittest

from src.catalog import Catalog


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.catalog = Catalog({"books": ["novel"], "music": ["jazz"]})

    def test_resolves_existing_canonical_keys(self):
        self.assertEqual(self.catalog.resolve("books"), ["novel"])
        self.assertEqual(self.catalog.resolve("music"), ["jazz"])

    def test_unknown_key_raises_key_error(self):
        with self.assertRaises(KeyError):
            self.catalog.resolve("missing")

    def test_alias_resolves_to_canonical_value_and_key(self):
        catalog = Catalog(
            {"books": ["novel"]},
            [("reading", "books"), ("favorite", "reading")],
        )

        self.assertEqual(catalog.resolve("reading"), ["novel"])
        self.assertEqual(catalog.resolve("favorite"), ["novel"])
        self.assertEqual(catalog.canonical_key("books"), "books")
        self.assertEqual(catalog.canonical_key("favorite"), "books")

    def test_aliases_none_or_empty_are_supported(self):
        self.assertEqual(Catalog({"books": 1}, None).resolve("books"), 1)
        self.assertEqual(Catalog({"books": 1}, []).resolve("books"), 1)

    def test_unknown_canonical_key_is_a_key_error(self):
        catalog = Catalog({"books": 1}, [("reading", "books")])

        with self.assertRaises(KeyError):
            catalog.resolve("missing")
        with self.assertRaises(KeyError):
            catalog.canonical_key("missing")

    def test_alias_chains_can_use_forward_references(self):
        catalog = Catalog(
            {"books": 1},
            [("favorite", "reading"), ("reading", "books")],
        )

        self.assertEqual(catalog.resolve("favorite"), 1)
        self.assertEqual(catalog.canonical_key("favorite"), "books")

    def test_structural_errors_are_checked_before_resolution(self):
        with self.assertRaisesRegex(ValueError, "duplicate") as context:
            Catalog(
                {"books": 1},
                [("broken", "missing"), ("duplicate", "books"), ("duplicate", "books")],
            )
        self.assertIn("duplicate", str(context.exception))

    def test_canonical_collision_and_duplicate_alias_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "books"):
            Catalog({"books": 1}, [("books", "books")])
        with self.assertRaisesRegex(ValueError, "reading"):
            Catalog({"books": 1}, [("reading", "books"), ("reading", "books")])

    def test_missing_target_reports_initiating_alias(self):
        with self.assertRaisesRegex(ValueError, "first"):
            Catalog({"books": 1}, [("first", "second"), ("second", "missing")])

    def test_cycles_and_self_cycles_report_initiating_alias(self):
        with self.assertRaisesRegex(ValueError, "first"):
            Catalog({"books": 1}, [("first", "second"), ("second", "first")])
        with self.assertRaisesRegex(ValueError, "self"):
            Catalog({"books": 1}, [("self", "self")])

    def test_inputs_are_not_mutated(self):
        mapping = {"books": ["novel"]}
        aliases = [("reading", "books")]
        Catalog(mapping, aliases)

        self.assertEqual(mapping, {"books": ["novel"]})
        self.assertEqual(aliases, [("reading", "books")])


if __name__ == "__main__":
    unittest.main()
