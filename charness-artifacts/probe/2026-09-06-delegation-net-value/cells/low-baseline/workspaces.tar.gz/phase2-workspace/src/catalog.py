"""A minimal canonical-key catalog used by the consumer fixture."""

from __future__ import annotations


class Catalog:
    """Resolve values by canonical keys and their aliases."""

    def __init__(self, mapping, aliases=None):
        self._mapping = dict(mapping)
        self._aliases = {}

        # Do the structural pass before resolving anything.  In particular,
        # this ensures a duplicate declaration is reported even when an
        # earlier alias has a dangling target.
        declarations = list(aliases) if aliases is not None else []
        for alias, target in declarations:
            if alias in self._mapping or alias in self._aliases:
                raise ValueError(f"invalid alias {alias!r}")
            self._aliases[alias] = target

        self._canonical_for_alias = {}
        for alias in self._aliases:
            self._resolve_alias(alias, alias, set())

    def _resolve_alias(self, alias, initiating_alias, resolving):
        if alias in self._canonical_for_alias:
            return self._canonical_for_alias[alias]
        if alias in resolving:
            raise ValueError(f"invalid alias {initiating_alias!r}")

        resolving.add(alias)
        target = self._aliases[alias]
        if target in self._mapping:
            canonical = target
        elif target in self._aliases:
            canonical = self._resolve_alias(target, initiating_alias, resolving)
        else:
            raise ValueError(f"invalid alias {initiating_alias!r}")
        resolving.remove(alias)
        self._canonical_for_alias[alias] = canonical
        return canonical

    def resolve(self, key):
        return self._mapping[self.canonical_key(key)]

    def canonical_key(self, name):
        if name in self._mapping:
            return name
        if name in self._canonical_for_alias:
            return self._canonical_for_alias[name]
        raise KeyError(name)
