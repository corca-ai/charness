# Catalog fixture

This dependency-free seed exposes a deliberately small public API:

```python
from src.catalog import Catalog

catalog = Catalog({"books": ["novel"]})
catalog.resolve("books")
```

`Catalog(mapping)` performs canonical-key lookup, and the optional `aliases`
argument adds named aliases. An unknown key raises the normal `KeyError`.

## Alias design checkpoint

The constructor also accepts `Catalog(mapping, aliases=None)`. The canonical
mapping remains the source of truth: it is copied once, and each alias resolves
through an alias chain to the same stored value as its terminal canonical key.
`canonical_key(name)` exposes that terminal key. Canonical lookup and unknown
names retain ordinary dictionary behavior, including `KeyError`.

Alias declarations are structurally checked in input order before any targets
are resolved. Canonical-name collisions and duplicate aliases raise
`ValueError` containing the invalid alias name. Forward references, cycles, and
missing targets are then resolved in declaration order; invalid chains raise
`ValueError` containing the initiating alias. `None` means no aliases. The
constructor does not mutate caller-owned mapping or alias data.

### Durable next actions

1. Add focused tests for successful alias lookup, chains, validation ordering,
   cycle/missing-target errors, and input immutability.
2. Implement the constructor and lookup while retaining the copied canonical
   mapping.
3. Run the existing and new unittest suite.

Run the baseline with:

```text
python3 -m unittest discover -s tests -v
```
